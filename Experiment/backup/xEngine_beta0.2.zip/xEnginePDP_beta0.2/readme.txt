Warning: This program is distributed as a prototype for use in research only and WITHOUT ANY WARRANTY, even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. xEngine should NOT be used to verify policies for applications. xEngine includes Sun PDP codes to help users to compare xEngine and Sun PDP. But the Copyright of Sun PDP codes is belongs to Sun Microsystems. xEngine (excluding Sun PDP codes) follows GPLv3 license (check gpl-3.0.txt).

For introduction and user manual, please check introduction.txt.

Please email bugs and feature requests to feichen@cse.msu.edu.

Changes have been made in xEnginePDP_beta0.2.

1. Add the package for generating synthetic XACML policies. 

2. Add the package for generating XACML requests based on the given XACML policy.

3. Add the user mannual of using the these two new packages in the instruction.txt file.

4. Fix bugs of processing multi-valued requests.

